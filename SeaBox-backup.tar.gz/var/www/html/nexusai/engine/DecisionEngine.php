<?php

declare(strict_types=1);

require_once __DIR__ . '/Issue.php';
require_once __DIR__ . '/Task.php';

class DecisionEngine
{
    /**
     * تحويل المشكلة إلى مهمة إصلاح
     */
    public function decide(Issue $issue): ?Task
    {

        switch ($issue->type) {

            case "missing_link":
                return new Task(
                    "Pages",
                    "repair_link",
                    $issue->file
                );

            case "broken_link":
                return new Task(
                    "Pages",
                    "repair_link",
                    $issue->file
                );

            case "missing_image":
                return new Task(
                    "Assets",
                    "restore_image",
                    $issue->file
                );

            case "missing_css":
                return new Task(
                    "Assets",
                    "repair_css",
                    $issue->file
                );

            case "missing_js":
                return new Task(
                    "Assets",
                    "repair_js",
                    $issue->file
                );

            case "javascript":
                return new Task(
                    "JavaScript",
                    "repair",
                    $issue->file
                );

            case "css":
                return new Task(
                    "CSS",
                    "repair",
                    $issue->file
                );

            case "php":
                return new Task(
                    "PHP",
                    "repair",
                    $issue->file
                );

            case "database":
                return new Task(
                    "Database",
                    "repair",
                    $issue->file
                );

            case "api":
                return new Task(
                    "API",
                    "repair",
                    $issue->file
                );

            case "security":
                return new Task(
                    "Security",
                    "repair",
                    $issue->file
                );

            case "permission":
                return new Task(
                    "Permissions",
                    "repair",
                    $issue->file
                );

            default:
                return new Task(
                    "General",
                    "inspect",
                    $issue->file
                );

        }

    }

    /**
     * اقتراح أولوية التنفيذ
     */
    public function priority(Issue $issue): int
    {

        return match ($issue->severity) {

            "critical" => 100,

            "high" => 80,

            "medium" => 50,

            "low" => 20,

            default => 10

        };

    }

    /**
     * هل يمكن إصلاحها تلقائياً؟
     */
    public function autoRepair(Issue $issue): bool
    {

        return in_array(

            $issue->type,

            [

                "missing_link",
                "broken_link",
                "missing_image",
                "missing_css",
                "missing_js"

            ],

            true

        );

    }
}
<?php
namespace NexusAI\Engine;

class Suggestions {
    public function generate($issues) {
        $suggestions = [];
        
        foreach ($issues as $issue) {
            $suggestion = [
                'issue' => $issue->message,
                'file' => $issue->file,
                'line' => $issue->line,
                'recommendation' => $this->getRecommendation($issue)
            ];
            $suggestions[] = $suggestion;
        }
        
        return $suggestions;
    }
    
    private function getRecommendation(Issue $issue) {
        $recommendations = [
            'broken_link' => "تحقق من وجود الملف أو المجلد، أو قم بتصحيح المسار",
            'deprecated_function' => "استبدل الدالة المهمة بدالة حديثة",
            'debug_code' => "احذف أوعلق كود التصحيح قبل النشر",
            'old_syntax' => "استخدم let أو const بدلاً من var"
        ];
        
        return $recommendations[$issue->type] ?? "راجع الكود وتأكد من صحته";
    }
}
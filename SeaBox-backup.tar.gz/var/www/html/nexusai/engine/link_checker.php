<?php
namespace NexusAI\Engine;

class LinkChecker {
    public function check($file) {
        $issues = [];
        $content = file_get_contents($file);
        $lines = explode("\n", $content);
        
        foreach ($lines as $lineNum => $line) {
            // البحث عن روابط href و src
            if (preg_match_all('/(href|src)=["\']([^"\']+)["\']/', $line, $matches)) {
                foreach ($matches[2] as $url) {
                    if ($this->isBrokenLink($url, $file)) {
                        $issues[] = new Issue(
                            'broken_link',
                            $file,
                            $lineNum + 1,
                            "رابط مكسور: $url",
                            'high',
                            true,
                            null
                        );
                    }
                }
            }
        }
        
        return $issues;
    }
    
    private function isBrokenLink($url, $currentFile) {
        // تجاهل الروابط الخارجية
        if (filter_var($url, FILTER_VALIDATE_URL)) {
            return false;
        }
        
        // تجاهل الروابط التي تبدأ بـ # أو javascript:
        if (strpos($url, '#') === 0 || strpos($url, 'javascript:') === 0) {
            return false;
        }
        
        // فحص الملفات المحلية
        $basePath = dirname($currentFile);
        $fullPath = $basePath . '/' . $url;
        
        return !file_exists($fullPath);
    }
}
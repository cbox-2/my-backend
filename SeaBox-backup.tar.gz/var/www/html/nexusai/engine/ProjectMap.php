<?php

declare(strict_types=1);

class ProjectMap
{
    private array $files = [];

    public function build(string $root): void
    {
        $this->files = [];

        if (!is_dir($root)) {
            return;
        }

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator(
                $root,
                FilesystemIterator::SKIP_DOTS
            )
        );

        foreach ($iterator as $file) {

            if (!$file->isFile()) {
                continue;
            }

            $path = $file->getPathname();

            $this->files[] = [

                "name" => basename($path),

                "path" => $path,

                "extension" => strtolower(
                    pathinfo($path, PATHINFO_EXTENSION)
                ),

                "size" => filesize($path),

                "modified" => filemtime($path)

            ];

        }

    }

    public function all(): array
    {
        return $this->files;
    }

    public function count(): int
    {
        return count($this->files);
    }

    public function findByName(string $name): array
    {
        $result = [];

        foreach ($this->files as $file) {

            if (
                stripos(
                    $file["name"],
                    $name
                ) !== false
            ) {

                $result[] = $file;

            }

        }

        return $result;
    }

    public function findByExtension(string $extension): array
    {
        $result = [];

        foreach ($this->files as $file) {

            if (
                $file["extension"] ===
                strtolower($extension)
            ) {

                $result[] = $file;

            }

        }

        return $result;
    }

    public function exists(string $path): bool
    {
        return file_exists($path);
    }

    public function summary(): array
    {
        $summary = [];

        foreach ($this->files as $file) {

            $ext = $file["extension"];

            if (!isset($summary[$ext])) {

                $summary[$ext] = 0;

            }

            $summary[$ext]++;

        }

        ksort($summary);

        return $summary;
    }

    public function printSummary(): string
    {
        $text = "";

        $text .= "=========== Project Map ===========\n";
        $text .= "Files : " . $this->count() . "\n\n";

        foreach ($this->summary() as $ext => $count) {

            $text .= strtoupper($ext);

            $text .= " : ";

            $text .= $count;

            $text .= "\n";

        }

        return $text;
    }
}
<?php

declare(strict_types=1);

class Issue
{
    public string $id;
    public string $type;
    public string $file;
    public string $message;
    public string $severity;
    public bool $fixed;
    public int $timestamp;

    public function __construct(
        string $type,
        string $file,
        string $message,
        string $severity = "medium"
    ) {

        $this->id = uniqid("ISSUE_", true);

        $this->type = $type;

        $this->file = $file;

        $this->message = $message;

        $this->severity = strtolower($severity);

        $this->fixed = false;

        $this->timestamp = time();

    }

    public function markFixed(): void
    {
        $this->fixed = true;
    }

    public function isFixed(): bool
    {
        return $this->fixed;
    }

    public function toArray(): array
    {
        return [

            "id" => $this->id,

            "type" => $this->type,

            "file" => $this->file,

            "message" => $this->message,

            "severity" => $this->severity,

            "fixed" => $this->fixed,

            "timestamp" => $this->timestamp

        ];
    }

    public function __toString(): string
    {
        return "[" .
            strtoupper($this->severity) .
            "] " .
            $this->type .
            " | " .
            $this->file .
            " | " .
            $this->message;
    }
}
<?php
declare(strict_types=1);

require_once __DIR__.'/ApprovalManager.php';
require_once __DIR__.'/RepairEngine.php';

class Fixer
{
    private RepairEngine $repair;

    public function __construct()
    {
        $this->repair = new RepairEngine();
    }

    public function executeApproved(ApprovalManager $approval): array
    {
        $grouped=[];

        foreach($approval->approved() as $task){
            $grouped[$task->target][]=$task;
        }

        $results=[];

        foreach($grouped as $file=>$tasks){
            $results[]=$this->repair->executeFile($file,$tasks);
        }

        return $results;
    }

    public function report(array $results): string
    {
        $files=0;
        $fixes=0;

        $text="=====================================\n";
        $text.=" NexusAI Repair Report\n";
        $text.="=====================================\n\n";

        foreach($results as $r){
            $files++;
            $fixes += (int)($r['fixes'] ?? 0);

            $text.="File : {$r['file']}\n";
            $text.="Success : ".($r['success']?'YES':'NO')."\n";
            $text.="Message : {$r['message']}\n";
            if(!empty($r['backup'])){
                $text.="Backup : {$r['backup']}\n";
            }
            $text.="-------------------------------------\n";
        }

        $text.="Files repaired : {$files}\n";
        $text.="Total fixes : {$fixes}\n";

        return $text;
    }
}

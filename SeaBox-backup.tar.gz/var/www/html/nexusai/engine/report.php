<?php
namespace NexusAI\Engine;

class Report {
    public function generate($issues, $tasks = []) {
        $report = "📊 تقرير NexusAI\n";
        $report .= "================\n\n";
        
        $report .= "📈 الإحصائيات:\n";
        $report .= "• عدد المشاكل المكتشفة: " . count($issues) . "\n";
        $report .= "• عدد المهام المُنشأة: " . count($tasks) . "\n\n";
        
        // تصنيف حسب الخطورة
        $bySeverity = $this->groupBySeverity($issues);
        $report .= "🎯 حسب الخطورة:\n";
        foreach ($bySeverity as $severity => $count) {
            $report .= "• $severity: $count\n";
        }
        $report .= "\n";
        
        // تصنيف حسب النوع
        $byType = $this->groupByType($issues);
        $report .= "📋 حسب النوع:\n";
        foreach ($byType as $type => $count) {
            $report .= "• $type: $count\n";
        }
        $report .= "\n";
        
        // التفاصيل
        if (!empty($issues)) {
            $report .= "🔍 التفاصيل:\n";
            foreach ($issues as $issue) {
                $report .= "• [{$issue->severity}] {$issue->message}\n";
                $report .= "  الملف: {$issue->file} (سطر {$issue->line})\n\n";
            }
        }
        
        return $report;
    }
    
    private function groupBySeverity($issues) {
        $groups = [];
        foreach ($issues as $issue) {
            $severity = $issue->severity;
            if (!isset($groups[$severity])) {
                $groups[$severity] = 0;
            }
            $groups[$severity]++;
        }
        return $groups;
    }
    
    private function groupByType($issues) {
        $groups = [];
        foreach ($issues as $issue) {
            $type = $issue->type;
            if (!isset($groups[$type])) {
                $groups[$type] = 0;
            }
            $groups[$type]++;
        }
        return $groups;
    }
}
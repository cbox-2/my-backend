<?php

declare(strict_types=1);

require_once __DIR__ . '/Issue.php';

class Scanner
{
    private array $issues = [];

    public function add(Issue $issue): void
    {
        foreach ($this->issues as $old) {

            if (
                $old->type === $issue->type &&
                $old->file === $issue->file &&
                $old->message === $issue->message
            ) {
                return;
            }

        }

        $this->issues[] = $issue;
    }

    public function all(): array
    {
        return $this->issues;
    }

    public function count(): int
    {
        return count($this->issues);
    }

    public function hasIssues(): bool
    {
        return !empty($this->issues);
    }

    public function clear(): void
    {
        $this->issues = [];
    }

    public function first(): ?Issue
    {
        return $this->issues[0] ?? null;
    }

    public function last(): ?Issue
    {
        if (empty($this->issues)) {
            return null;
        }

        return $this->issues[array_key_last($this->issues)];
    }

    public function bySeverity(string $severity): array
    {
        $result = [];

        foreach ($this->issues as $issue) {

            if ($issue->severity === strtolower($severity)) {
                $result[] = $issue;
            }

        }

        return $result;
    }

    public function byType(string $type): array
    {
        $result = [];

        foreach ($this->issues as $issue) {

            if ($issue->type === $type) {
                $result[] = $issue;
            }

        }

        return $result;
    }

    public function statistics(): array
    {
        $stats = [
            "low" => 0,
            "medium" => 0,
            "high" => 0,
            "critical" => 0
        ];

        foreach ($this->issues as $issue) {

            if (isset($stats[$issue->severity])) {
                $stats[$issue->severity]++;
            }

        }

        return $stats;
    }

    public function printSummary(): void
    {
        echo PHP_EOL;
        echo "========== Scanner Summary ==========" . PHP_EOL;

        echo "Total Issues : " . $this->count() . PHP_EOL;

        $stats = $this->statistics();

        echo "Critical : " . $stats["critical"] . PHP_EOL;
        echo "High     : " . $stats["high"] . PHP_EOL;
        echo "Medium   : " . $stats["medium"] . PHP_EOL;
        echo "Low      : " . $stats["low"] . PHP_EOL;

        echo "=====================================" . PHP_EOL;
    }
}
<?php
namespace NexusAI\Engine;

class PhpChecker {
    public function check($file) {
        $issues = [];
        $content = file_get_contents($file);
        $lines = explode("\n", $content);
        
        foreach ($lines as $lineNum => $line) {
            // فحص الدوال المهملة
            if (preg_match('/\b(mysql_|ereg|split\()/', $line)) {
                $issues[] = new Issue(
                    'deprecated_function',
                    $file,
                    $lineNum + 1,
                    "دالة مهملة مستخدمة",
                    'medium',
                    false,
                    null
                );
            }
            
            // فحص المتغيرات غير المعرفة
            if (preg_match('/\$\w+/', $line) && !preg_match('/function|class|=>/', $line)) {
                // يمكن إضافة فحص أكثر تعقيداً هنا
            }
            
            // فحص الأخطاء النحوية البسيطة
            if (preg_match('/;\s*$/', trim($line)) && preg_match('/echo|print/', $line)) {
                // جملة echo/print صحيحة
            }
        }
        
        return $issues;
    }
}
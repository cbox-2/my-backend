<?php

declare(strict_types=1);

require_once __DIR__ . '/Task.php';
require_once __DIR__ . '/BackupManager.php';
require_once __DIR__ . '/FileManager.php';

class RepairEngine
{
    private BackupManager $backup;

    private FileManager $files;

    public function __construct()
    {
        $this->backup = new BackupManager();
        $this->files = new FileManager();
    }

    /**
     * تنفيذ مهمة إصلاح
     */
    public function execute(Task $task): array
    {
        $result = [
            "success" => false,
            "backup" => null,
            "message" => ""
        ];

        if (!file_exists($task->target)) {

            $result["message"] = "Target file not found.";

            return $result;

        }

        $backup = $this->backup->backup($task->target);

        $result["backup"] = $backup;

        switch ($task->action) {

            case "repair_link":

                $fixed = $this->repairLinks($task->target);

                $result["success"] = true;
                $result["message"] = "Links repaired: " . $fixed;

                break;

            case "restore_image":

                $result["success"] = true;
                $result["message"] =
                    "Image restore task prepared.";

                break;

            case "repair_css":

                $result["success"] = true;
                $result["message"] =
                    "CSS repair task prepared.";

                break;

            case "repair_js":

                $result["success"] = true;
                $result["message"] =
                    "JavaScript repair task prepared.";

                break;

            case "repair":

                $result["success"] = true;
                $result["message"] =
                    "General repair task prepared.";

                break;

            case "inspect":

                $result["success"] = true;
                $result["message"] =
                    "Inspection completed.";

                break;

            default:

                $result["message"] =
                    "Unknown repair action.";

                break;

        }

        if ($result["success"]) {

            $task->complete();

        }

        return $result;
    }

    /**
     * إصلاح الروابط داخل الملف
     */
    private function repairLinks(string $file): int
    {
        $content = $this->files->read($file);

        if ($content === null) {
            return 0;
        }

        $count = 0;

        $replacements = [

            "/public/admin/preproc=logout"
                => "/public/admin/logout/",

            "/public/support/"
                => "/public/contact/",

            "/gfx/logo400.png"
                => "/gfx/logo.png",

            "/gfx/logo.gif"
                => "/gfx/logo.png",

        ];

        foreach ($replacements as $old => $new) {

            $found = substr_count($content, $old);

            if ($found > 0) {

                $content = str_replace(
                    $old,
                    $new,
                    $content
                );

                $count += $found;

            }

        }

        $this->files->write(
            $file,
            $content
        );

        return $count;
    }

    /**
     * استرجاع النسخة الاحتياطية
     */
    public function rollback(
        string $backupFile,
        string $targetFile
    ): bool
    {
        return $this->backup->restore(
            $backupFile,
            $targetFile
        );
    }
}
<?php

declare(strict_types=1);

class Task
{
    public string $id;

    public string $module;

    public string $action;

    public string $target;

    public string $status;

    public int $createdAt;

    public function __construct(
        string $module,
        string $action,
        string $target
    ) {

        $this->id = uniqid("TASK_", true);

        $this->module = $module;

        $this->action = $action;

        $this->target = $target;

        $this->status = "pending";

        $this->createdAt = time();

    }

    public function approve(): void
    {
        $this->status = "approved";
    }

    public function reject(): void
    {
        $this->status = "rejected";
    }

    public function complete(): void
    {
        $this->status = "completed";
    }

    public function isPending(): bool
    {
        return $this->status === "pending";
    }

    public function isApproved(): bool
    {
        return $this->status === "approved";
    }

    public function toArray(): array
    {
        return [

            "id" => $this->id,

            "module" => $this->module,

            "action" => $this->action,

            "target" => $this->target,

            "status" => $this->status,

            "createdAt" => $this->createdAt

        ];
    }

    public function __toString(): string
    {
        return
            $this->module .
            " | " .
            $this->action .
            " | " .
            $this->target .
            " | " .
            strtoupper($this->status);
    }
}
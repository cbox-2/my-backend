<?php

declare(strict_types=1);

require_once __DIR__ . '/Task.php';

class ApprovalManager
{
    private array $tasks = [];

    private string $file;

    public function __construct()
    {
        $this->file = __DIR__ . '/../reports/tasks.json';

        if (!is_dir(dirname($this->file))) {
            mkdir(dirname($this->file), 0777, true);
        }

        $this->load();
    }

    /**
     * تحميل المهام من الملف
     */
    private function load(): void
    {
        if (!file_exists($this->file)) {
            return;
        }

        $data = json_decode(
            file_get_contents($this->file),
            true
        );

        if (!is_array($data)) {
            return;
        }

        foreach ($data as $item) {

            $task = new Task(
                $item["module"],
                $item["action"],
                $item["target"]
            );

            $task->id = $item["id"];
            $task->status = $item["status"];
            $task->createdAt = $item["createdAt"];

            $this->tasks[$task->id] = $task;
        }
    }

    /**
     * حفظ المهام
     */
    private function save(): void
    {
        $data = [];

        foreach ($this->tasks as $task) {
            $data[] = $task->toArray();
        }

        file_put_contents(
            $this->file,
            json_encode(
                $data,
                JSON_PRETTY_PRINT |
                JSON_UNESCAPED_UNICODE |
                JSON_UNESCAPED_SLASHES
            )
        );
    }

    /**
     * إضافة مهمة
     */
    public function add(Task $task): void
    {
        $this->tasks[$task->id] = $task;

        $this->save();
    }

    /**
     * جميع المهام
     */
    public function all(): array
    {
        return array_values($this->tasks);
    }

    /**
     * عدد المهام
     */
    public function count(): int
    {
        return count($this->tasks);
    }

    /**
     * البحث عن مهمة
     */
    public function find(string $id): ?Task
    {
        return $this->tasks[$id] ?? null;
    }

    /**
     * الموافقة على مهمة
     */
    public function approve(string $id): bool
    {
        if (!isset($this->tasks[$id])) {
            return false;
        }

        $this->tasks[$id]->approve();

        $this->save();

        return true;
    }

    /**
     * رفض مهمة
     */
    public function reject(string $id): bool
    {
        if (!isset($this->tasks[$id])) {
            return false;
        }

        $this->tasks[$id]->reject();

        $this->save();

        return true;
    }

    /**
     * حذف مهمة
     */
    public function remove(string $id): bool
    {
        if (!isset($this->tasks[$id])) {
            return false;
        }

        unset($this->tasks[$id]);

        $this->save();

        return true;
    }

    /**
     * حذف جميع المهام
     */
    public function clear(): void
    {
        $this->tasks = [];

        $this->save();
    }

    /**
     * المهام الموافق عليها
     */
    public function approved(): array
    {
        return array_values(
            array_filter(
                $this->tasks,
                fn(Task $task) => $task->status === "approved"
            )
        );
    }

    /**
     * المهام المعلقة
     */
    public function pending(): array
    {
        return array_values(
            array_filter(
                $this->tasks,
                fn(Task $task) => $task->status === "pending"
            )
        );
    }

    /**
     * المهام المرفوضة
     */
    public function rejected(): array
    {
        return array_values(
            array_filter(
                $this->tasks,
                fn(Task $task) => $task->status === "rejected"
            )
        );
    }
}
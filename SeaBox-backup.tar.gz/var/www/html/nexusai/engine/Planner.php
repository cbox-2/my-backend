<?php

declare(strict_types=1);

class Planner
{
    public function createPlan(array $intent): array
    {
        $plan = [

            "intent" => $intent["intent"],

            "entity" => $intent["entity"],

            "confidence" => $intent["confidence"],

            "steps" => [],

            "requiresApproval" => true

        ];

        switch ($intent["intent"]) {

            case "scan_project":

                $plan["steps"] = [

                    "Scan project files",

                    "Analyze source code",

                    "Collect issues",

                    "Generate report"

                ];

                break;

            case "repair_project":

                $plan["steps"] = [

                    "Scan project",

                    "Create backup",

                    "Generate repair tasks",

                    "Wait for approval",

                    "Execute repairs",

                    "Verify repairs",

                    "Generate final report"

                ];

                break;

            case "show_issues":

                $plan["steps"] = [

                    "Load issues",

                    "Sort by severity",

                    "Display results"

                ];

                $plan["requiresApproval"] = false;

                break;

            case "show_tasks":

                $plan["steps"] = [

                    "Load tasks",

                    "Display task list"

                ];

                $plan["requiresApproval"] = false;

                break;

            case "execute_repairs":

                $plan["steps"] = [

                    "Verify approval",

                    "Backup files",

                    "Execute repairs",

                    "Verify project",

                    "Write log"

                ];

                break;

            case "statistics":

                $plan["steps"] = [

                    "Collect statistics",

                    "Display report"

                ];

                $plan["requiresApproval"] = false;

                break;

            default:

                $plan["steps"] = [

                    "Unknown command",

                    "Waiting for user"

                ];

                $plan["requiresApproval"] = false;

                break;

        }

        return $plan;
    }

    public function printPlan(array $plan): string
    {
        $text = "";

        $text .= "========== PLAN ==========\n";

        $text .= "Intent : ";

        $text .= $plan["intent"];

        $text .= "\n";

        $text .= "Confidence : ";

        $text .= $plan["confidence"];

        $text .= "%\n";

        if (!empty($plan["entity"])) {

            $text .= "Entity : ";

            $text .= $plan["entity"];

            $text .= "\n";

        }

        $text .= "\nSteps\n";

        $text .= "--------------------------\n";

        foreach ($plan["steps"] as $i => $step) {

            $text .= ($i + 1);

            $text .= ". ";

            $text .= $step;

            $text .= "\n";

        }

        $text .= "\nApproval : ";

        $text .= $plan["requiresApproval"]
            ? "Required"
            : "Not Required";

        return $text;
    }
}
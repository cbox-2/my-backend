<?php

declare(strict_types=1);

class IntentAnalyzer
{
    public function analyze(string $command): array
    {
        $command = mb_strtolower(trim($command), 'UTF-8');

        $intent = "unknown";

        $entity = "";

        $confidence = 0;

        /*
        -------------------------
        فحص المشروع
        -------------------------
        */

        if (
            $this->contains(
                $command,
                [
                    "فحص المشروع",
                    "افحص المشروع",
                    "حلل المشروع",
                    "scan project",
                    "scan"
                ]
            )
        ) {

            $intent = "scan_project";
            $confidence = 100;

        }

        /*
        -------------------------
        إصلاح المشروع
        -------------------------
        */

        else if (
            $this->contains(
                $command,
                [
                    "اصلح المشروع",
                    "إصلاح المشروع",
                    "صلح المشروع",
                    "repair project"
                ]
            )
        ) {

            $intent = "repair_project";
            $confidence = 100;

        }

        /*
        -------------------------
        عرض المشاكل
        -------------------------
        */

        else if (
            $this->contains(
                $command,
                [
                    "اعرض المشاكل",
                    "المشاكل",
                    "الأخطاء",
                    "issues"
                ]
            )
        ) {

            $intent = "show_issues";
            $confidence = 100;

        }

        /*
        -------------------------
        عرض المهام
        -------------------------
        */

        else if (
            $this->contains(
                $command,
                [
                    "اعرض المهام",
                    "المهام",
                    "tasks"
                ]
            )
        ) {

            $intent = "show_tasks";
            $confidence = 100;

        }

        /*
        -------------------------
        تنفيذ الإصلاح
        -------------------------
        */

        else if (
            $this->contains(
                $command,
                [
                    "نفذ الإصلاح",
                    "ابدأ الإصلاح",
                    "اصلح",
                    "نفذ"
                ]
            )
        ) {

            $intent = "execute_repairs";
            $confidence = 95;

        }

        /*
        -------------------------
        إحصائيات
        -------------------------
        */

        else if (
            $this->contains(
                $command,
                [
                    "احصائيات",
                    "الإحصائيات",
                    "statistics"
                ]
            )
        ) {

            $intent = "statistics";
            $confidence = 100;

        }

        /*
        -------------------------
        البحث عن ملف
        -------------------------
        */

        if (
            preg_match(
                '/([A-Za-z0-9_\-]+\.(php|html|js|css))/i',
                $command,
                $match
            )
        ) {

            $entity = $match[1];

        }

        return [

            "intent" => $intent,

            "entity" => $entity,

            "confidence" => $confidence,

            "command" => $command

        ];

    }

    private function contains(
        string $text,
        array $words
    ): bool
    {

        foreach ($words as $word) {

            if (
                mb_stripos(
                    $text,
                    $word,
                    0,
                    'UTF-8'
                ) !== false
            ) {

                return true;

            }

        }

        return false;

    }
}
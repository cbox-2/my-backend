<?php
namespace NexusAI\Engine;

class JsChecker {
    public function check($file) {
        $issues = [];
        $content = file_get_contents($file);
        $lines = explode("\n", $content);
        
        foreach ($lines as $lineNum => $line) {
            // فحص console.log
            if (preg_match('/console\.log/', $line)) {
                $issues[] = new Issue(
                    'debug_code',
                    $file,
                    $lineNum + 1,
                    "كود تصحيح (console.log) موجود",
                    'low',
                    true,
                    preg_replace('/console\.log\([^)]*\);?/', '', $line)
                );
            }
            
            // فحص var القديم
            if (preg_match('/\bvar\s+/', $line)) {
                $issues[] = new Issue(
                    'old_syntax',
                    $file,
                    $lineNum + 1,
                    "استخدام var القديم (يُنصح بـ let/const)",
                    'low',
                    true,
                    preg_replace('/\bvar\b/', 'let', $line)
                );
            }
        }
        
        return $issues;
    }
}
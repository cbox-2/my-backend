<?php

declare(strict_types=1);

class FileManager
{
    /**
     * قراءة ملف
     */
    public function read(string $file): ?string
    {
        if (!file_exists($file) || !is_file($file)) {
            return null;
        }

        return file_get_contents($file);
    }

    /**
     * كتابة ملف
     */
    public function write(string $file, string $content): bool
    {
        $dir = dirname($file);

        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }

        return file_put_contents($file, $content) !== false;
    }

    /**
     * إضافة نص إلى نهاية الملف
     */
    public function append(string $file, string $content): bool
    {
        return file_put_contents(
            $file,
            $content,
            FILE_APPEND
        ) !== false;
    }

    /**
     * حذف ملف
     */
    public function delete(string $file): bool
    {
        if (!file_exists($file)) {
            return false;
        }

        return unlink($file);
    }

    /**
     * نسخ ملف
     */
    public function copy(string $source, string $destination): bool
    {
        if (!file_exists($source)) {
            return false;
        }

        $dir = dirname($destination);

        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }

        return copy($source, $destination);
    }

    /**
     * نقل ملف
     */
    public function move(string $source, string $destination): bool
    {
        if (!file_exists($source)) {
            return false;
        }

        $dir = dirname($destination);

        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }

        return rename($source, $destination);
    }

    /**
     * هل الملف موجود؟
     */
    public function exists(string $file): bool
    {
        return file_exists($file);
    }

    /**
     * حجم الملف
     */
    public function size(string $file): int
    {
        if (!$this->exists($file)) {
            return 0;
        }

        return filesize($file);
    }

    /**
     * آخر تعديل
     */
    public function modified(string $file): int
    {
        if (!$this->exists($file)) {
            return 0;
        }

        return filemtime($file);
    }

    /**
     * البحث عن الملفات
     */
    public function find(string $root, string $name): array
    {
        $result = [];

        if (!is_dir($root)) {
            return [];
        }

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator(
                $root,
                FilesystemIterator::SKIP_DOTS
            )
        );

        foreach ($iterator as $file) {

            if (!$file->isFile()) {
                continue;
            }

            if (
                stripos(
                    $file->getFilename(),
                    $name
                ) !== false
            ) {

                $result[] = $file->getPathname();

            }

        }

        return $result;
    }
}
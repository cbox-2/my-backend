<?php

declare(strict_types=1);

class Memory
{
    private string $file;

    public function __construct(
        string $file = __DIR__ . '/../storage/memory.json'
    ) {

        $this->file = $file;

        $dir = dirname($this->file);

        if (!is_dir($dir)) {

            mkdir($dir, 0777, true);

        }

        if (!file_exists($this->file)) {

            file_put_contents(
                $this->file,
                json_encode([], JSON_PRETTY_PRINT)
            );

        }

    }

    /**
     * قراءة الذاكرة
     */
    public function load(): array
    {

        $json = @file_get_contents($this->file);

        if ($json === false || trim($json) === "") {
            return [];
        }

        $data = json_decode($json, true);

        if (!is_array($data)) {
            return [];
        }

        return $data;

    }

    /**
     * حفظ الذاكرة
     */
    public function save(array $memory): bool
    {

        return file_put_contents(

            $this->file,

            json_encode(

                $memory,

                JSON_PRETTY_PRINT |
                JSON_UNESCAPED_UNICODE

            )

        ) !== false;

    }

    /**
     * إضافة سجل جديد
     */
    public function add(
        string $type,
        string $message
    ): void
    {

        $memory = $this->load();

        $memory[] = [

            "time" => date("Y-m-d H:i:s"),

            "type" => $type,

            "message" => $message

        ];

        $this->save($memory);

    }

    /**
     * جميع السجلات
     */
    public function all(): array
    {
        return $this->load();
    }

    /**
     * آخر سجل
     */
    public function last(): ?array
    {

        $memory = $this->load();

        if (empty($memory)) {
            return null;
        }

        return $memory[array_key_last($memory)];

    }

    /**
     * حذف الذاكرة
     */
    public function clear(): void
    {
        $this->save([]);
    }

    /**
     * البحث داخل الذاكرة
     */
    public function search(string $keyword): array
    {

        $result = [];

        foreach ($this->load() as $row) {

            if (
                stripos(
                    $row["message"],
                    $keyword
                ) !== false
            ) {

                $result[] = $row;

            }

        }

        return $result;

    }

    /**
     * عدد السجلات
     */
    public function count(): int
    {
        return count($this->load());
    }

}
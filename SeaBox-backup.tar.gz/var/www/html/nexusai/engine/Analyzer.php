<?php

declare(strict_types=1);

require_once __DIR__ . '/Scanner.php';
require_once __DIR__ . '/Issue.php';

class Analyzer
{
    private Scanner $scanner;

    public function __construct(Scanner $scanner)
    {
        $this->scanner = $scanner;
    }

    public function analyze(string $projectPath): void
    {
        if (!is_dir($projectPath)) {

            $this->scanner->add(
                new Issue(
                    "project",
                    $projectPath,
                    "Project directory not found.",
                    "critical"
                )
            );

            return;
        }

        $this->scanDirectory($projectPath);
    }

    private function scanDirectory(string $path): void
    {
        $items = @scandir($path);

        if ($items === false) {
            return;
        }

        foreach ($items as $item) {

            if ($item === "." || $item === "..") {
                continue;
            }

            $full = $path . DIRECTORY_SEPARATOR . $item;

            if (is_dir($full)) {

                if (basename($full) === "nexusai") {
                    continue;
                }

                $this->scanDirectory($full);
                continue;
            }

            $this->analyzeFile($full);
        }
    }

    private function analyzeFile(string $file): void
    {
        $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));

        switch ($ext) {

            case "php":
            case "html":
                $this->checkLinks($file);
                break;

            case "css":
                $this->checkCss($file);
                break;

            case "js":
                $this->checkJavaScript($file);
                break;
        }
    }

    private function checkLinks(string $file): void
    {
        $content = @file_get_contents($file);

        if ($content === false) {
            return;
        }

        preg_match_all(
            '/(?:href|src)=["\']([^"\']+)["\']/i',
            $content,
            $matches
        );

        foreach ($matches[1] as $link) {

            $link = trim($link);

            if (
                $link === "" ||
                str_starts_with($link, "#") ||
                str_starts_with($link, "javascript:") ||
                str_starts_with($link, "mailto:") ||
                str_starts_with($link, "tel:") ||
                str_starts_with($link, "http://") ||
                str_starts_with($link, "https://") ||
                str_contains($link, "<?") ||
                str_starts_with($link, "?")
            ) {
                continue;
            }

            if (str_starts_with($link, "/")) {
                $target = "/var/www/html" . $link;
            } else {
                $target = dirname($file) . "/" . $link;
            }

            if (!file_exists($target)) {

                $this->scanner->add(

                    new Issue(
                        "missing_link",
                        $file,
                        "Missing link: " . $link,
                        "medium"
                    )

                );
            }
        }
    }

    private function checkCss(string $file): void
    {
        if (filesize($file) === 0) {

            $this->scanner->add(
                new Issue(
                    "css",
                    $file,
                    "Empty CSS file.",
                    "low"
                )
            );

        }
    }

    private function checkJavaScript(string $file): void
    {
        if (filesize($file) === 0) {

            $this->scanner->add(
                new Issue(
                    "javascript",
                    $file,
                    "Empty JavaScript file.",
                    "low"
                )
            );

        }
    }
}
<?php

declare(strict_types=1);

require_once __DIR__ . '/Scanner.php';
require_once __DIR__ . '/Analyzer.php';

class VerificationEngine
{
    /**
     * إعادة فحص المشروع بالكامل
     */
    public function verifyProject(string $projectPath): array
    {
        $scanner = new Scanner();

        $analyzer = new Analyzer($scanner);

        $analyzer->analyze($projectPath);

        return [

            "success" => !$scanner->hasIssues(),

            "issues" => $scanner->count(),

            "statistics" => $scanner->statistics(),

            "scanner" => $scanner

        ];
    }

    /**
     * إنشاء تقرير بعد التحقق
     */
    public function report(array $result): string
    {
        $text = "";

        $text .= "=====================================\n";
        $text .= " NexusAI Verification Report\n";
        $text .= "=====================================\n\n";

        if ($result["success"]) {

            $text .= "Status : SUCCESS\n";
            $text .= "No issues found.\n";

        } else {

            $text .= "Status : FAILED\n";
            $text .= "Remaining Issues : ";
            $text .= $result["issues"];
            $text .= "\n\n";

            $stats = $result["statistics"];

            $text .= "Critical : ";
            $text .= $stats["critical"];
            $text .= "\n";

            $text .= "High : ";
            $text .= $stats["high"];
            $text .= "\n";

            $text .= "Medium : ";
            $text .= $stats["medium"];
            $text .= "\n";

            $text .= "Low : ";
            $text .= $stats["low"];
            $text .= "\n";

        }

        return $text;
    }

    /**
     * هل الإصلاح ناجح؟
     */
    public function passed(array $result): bool
    {
        return $result["success"];
    }
}
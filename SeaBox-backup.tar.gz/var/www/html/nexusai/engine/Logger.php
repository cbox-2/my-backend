<?php

declare(strict_types=1);

class Logger
{
    private string $logDirectory;

    public function __construct(
        string $logDirectory = __DIR__ . '/../logs'
    ) {

        $this->logDirectory = $logDirectory;

        if (!is_dir($this->logDirectory)) {

            mkdir(
                $this->logDirectory,
                0777,
                true
            );

        }

    }

    /**
     * كتابة سجل
     */
    public function write(
        string $level,
        string $message
    ): bool
    {

        $file = $this->logDirectory . "/"
              . date("Y-m-d")
              . ".log";

        $line =
            "[" .
            date("Y-m-d H:i:s") .
            "] [" .
            strtoupper($level) .
            "] " .
            $message .
            PHP_EOL;

        return file_put_contents(
            $file,
            $line,
            FILE_APPEND | LOCK_EX
        ) !== false;

    }

    public function info(string $message): bool
    {
        return $this->write(
            "info",
            $message
        );
    }

    public function warning(string $message): bool
    {
        return $this->write(
            "warning",
            $message
        );
    }

    public function error(string $message): bool
    {
        return $this->write(
            "error",
            $message
        );
    }

    public function success(string $message): bool
    {
        return $this->write(
            "success",
            $message
        );
    }

    /**
     * قراءة سجل يوم معين
     */
    public function read(
        ?string $date = null
    ): string
    {

        if ($date === null) {

            $date = date("Y-m-d");

        }

        $file = $this->logDirectory . "/"
              . $date
              . ".log";

        if (!file_exists($file)) {

            return "";

        }

        return file_get_contents($file);

    }

    /**
     * حذف جميع السجلات
     */
    public function clear(): void
    {

        foreach (
            glob($this->logDirectory . "/*.log")
            as
            $file
        ) {

            @unlink($file);

        }

    }

    /**
     * عدد ملفات السجل
     */
    public function count(): int
    {

        return count(
            glob(
                $this->logDirectory . "/*.log"
            )
        );

    }
}
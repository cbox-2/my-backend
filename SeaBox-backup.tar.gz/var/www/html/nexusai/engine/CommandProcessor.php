<?php

declare(strict_types=1);

require_once __DIR__ . '/Scanner.php';
require_once __DIR__ . '/Analyzer.php';
require_once __DIR__ . '/DecisionEngine.php';
require_once __DIR__ . '/ApprovalManager.php';
require_once __DIR__ . '/RepairEngine.php';
require_once __DIR__ . '/Fixer.php';

class CommandProcessor
{
    private Scanner $scanner;

    private Analyzer $analyzer;

    private DecisionEngine $decision;

    private ApprovalManager $approval;

    private Fixer $fixer;

    private string $project;

    public function __construct(string $project)
    {
        $this->project = $project;

        $this->scanner = new Scanner();

        $this->analyzer = new Analyzer(
            $this->scanner
        );

        $this->decision = new DecisionEngine();

        $this->approval = new ApprovalManager();

        $this->fixer = new Fixer();
    }

    public function process(string $command): string
    {
        $command = trim($command);

        if ($command === "") {
            return "لم يتم إدخال أي أمر.";
        }

        switch ($command) {

            case "فحص المشروع":
                return $this->scanProject($this->project);

            case "اعرض المشاكل":
                return $this->showIssues();

            case "اعرض المهام":
                return $this->showTasks();

            case "نفذ الإصلاح":
                return $this->runRepairs();

            case "الإحصائيات":
                return $this->statistics();

            default:
                return "الأمر غير معروف:\n\n" . $command;
        }
    }

    private function scanProject(string $project): string
    {
        $this->scanner->clear();

        $this->approval->clear();

        $this->analyzer->analyze($project);

        foreach ($this->scanner->all() as $issue) {

            $task = $this->decision->decide($issue);

            if ($task !== null) {
                $this->approval->add($task);
            }
        }

        $text = "";

        $text .= "تم فحص المشروع.\n\n";
        $text .= "عدد المشاكل: ";
        $text .= $this->scanner->count();
        $text .= "\n";
        $text .= "عدد المهام: ";
        $text .= $this->approval->count();

        return $text;
    }

    private function showIssues(): string
    {
        if (!$this->scanner->hasIssues()) {
            return "لا توجد مشاكل.";
        }

        $text = "";

        foreach ($this->scanner->all() as $issue) {

            $text .= "[" . strtoupper($issue->severity) . "] ";
            $text .= $issue->type . "\n";
            $text .= $issue->file . "\n";
            $text .= $issue->message . "\n\n";
        }

        return $text;
    }

    private function showTasks(): string
    {
        $tasks = $this->approval->all();

        if (empty($tasks)) {
            return "لا توجد مهام.";
        }

        $text = "";

        foreach ($tasks as $task) {

            $text .= "ID : " . $task->id . "\n";
            $text .= "Module : " . $task->module . "\n";
            $text .= "Action : " . $task->action . "\n";
            $text .= "Target : " . $task->target . "\n";
            $text .= "Status : " . $task->status . "\n";
            $text .= "------------------------------\n";
        }

        return $text;
    }

    private function runRepairs(): string
    {
        $tasks = $this->approval->all();

        if (empty($tasks)) {
            return "لا توجد مهام للإصلاح.";
        }

        foreach ($tasks as $task) {

            if ($task->status === "pending") {
                $task->approve();
            }
        }

        $results = $this->fixer->executeApproved(
            $this->approval
        );

        return $this->fixer->report($results);
    }

    private function statistics(): string
    {
        $stats = $this->scanner->statistics();

        $text = "";

        $text .= "========== NexusAI ==========\n";
        $text .= "Issues : " . $this->scanner->count() . "\n";
        $text .= "Tasks : " . $this->approval->count() . "\n\n";
        $text .= "Critical : " . $stats["critical"] . "\n";
        $text .= "High : " . $stats["high"] . "\n";
        $text .= "Medium : " . $stats["medium"] . "\n";
        $text .= "Low : " . $stats["low"] . "\n";

        return $text;
    }
}
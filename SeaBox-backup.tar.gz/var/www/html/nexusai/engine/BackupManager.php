<?php

declare(strict_types=1);

class BackupManager
{
    private string $backupPath;

    public function __construct(
        string $backupPath = __DIR__ . '/../backups'
    ) {

        $this->backupPath = $backupPath;

        if (!is_dir($this->backupPath)) {

            mkdir(
                $this->backupPath,
                0777,
                true
            );

        }

    }

    /**
     * إنشاء نسخة احتياطية لملف
     */
    public function backup(string $file): ?string
    {

        if (!file_exists($file)) {
            return null;
        }

        $relative = ltrim(
            str_replace("/var/www/html", "", $file),
            "/"
        );

        $destination = $this->backupPath .
            "/" .
            date("Ymd_His") .
            "_" .
            str_replace("/", "_", $relative);

        if (copy($file, $destination)) {

            return $destination;

        }

        return null;

    }

    /**
     * استرجاع نسخة احتياطية
     */
    public function restore(
        string $backupFile,
        string $targetFile
    ): bool
    {

        if (!file_exists($backupFile)) {
            return false;
        }

        return copy(
            $backupFile,
            $targetFile
        );

    }

    /**
     * حذف نسخة احتياطية
     */
    public function delete(
        string $backupFile
    ): bool
    {

        if (!file_exists($backupFile)) {
            return false;
        }

        return unlink($backupFile);

    }

    /**
     * جميع النسخ الاحتياطية
     */
    public function all(): array
    {

        $files = glob(
            $this->backupPath . "/*"
        );

        return $files ?: [];

    }

    /**
     * عدد النسخ الاحتياطية
     */
    public function count(): int
    {

        return count(
            $this->all()
        );

    }

    /**
     * آخر نسخة احتياطية
     */
    public function latest(): ?string
    {

        $files = $this->all();

        if (empty($files)) {
            return null;
        }

        usort(
            $files,
            fn($a, $b) => filemtime($b) <=> filemtime($a)
        );

        return $files[0];

    }

    /**
     * تنظيف النسخ القديمة
     */
    public function clean(
        int $keep = 20
    ): void
    {

        $files = $this->all();

        usort(
            $files,
            fn($a, $b) => filemtime($b) <=> filemtime($a)
        );

        if (count($files) <= $keep) {
            return;
        }

        $old = array_slice($files, $keep);

        foreach ($old as $file) {

            @unlink($file);

        }

    }
}
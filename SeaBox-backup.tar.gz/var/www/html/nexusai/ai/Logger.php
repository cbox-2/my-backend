<?php

class Logger
{
    public static function write($message)
    {
        $file = Config::$logDir . "/nexusai.log";

        $time = date("Y-m-d H:i:s");

        file_put_contents(
            $file,
            "[".$time."] ".$message.PHP_EOL,
            FILE_APPEND
        );
    }
}
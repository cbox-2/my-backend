<?php

class Config
{
    public static string $projectRoot = "/var/www/html";

    public static string $publicDir = "/var/www/html/public";

    public static string $apiDir = "/var/www/html/api";

    public static string $adminDir = "/var/www/html/public/admin";

    public static string $backupDir = "/var/www/html/nexusai/backups";

    public static string $reportDir = "/var/www/html/nexusai/reports";

    public static string $logDir = "/var/www/html/nexusai/logs";

    public static string $templateDir = "/var/www/html/nexusai/templates";

    public static string $host = "http://localhost";

    public static string $dbHost = "localhost";

    public static string $dbName = "nexusbox_db";

    public static string $dbUser = "nexusbox";

    public static string $dbPass = "NexusBox2026";
}
<?php

class Utils
{

    public static function ok($text)
    {
        echo "[OK] ".$text.PHP_EOL;
    }

    public static function error($text)
    {
        echo "[ERROR] ".$text.PHP_EOL;
    }

    public static function info($text)
    {
        echo "[INFO] ".$text.PHP_EOL;
    }

}
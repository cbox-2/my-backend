<?php

declare(strict_types=1);

date_default_timezone_set('Asia/Baghdad');

require_once __DIR__ . '/engine/Issue.php';
require_once __DIR__ . '/engine/Task.php';
require_once __DIR__ . '/engine/Scanner.php';
require_once __DIR__ . '/engine/Analyzer.php';
require_once __DIR__ . '/engine/DecisionEngine.php';
require_once __DIR__ . '/engine/ApprovalManager.php';
require_once __DIR__ . '/engine/BackupManager.php';
require_once __DIR__ . '/engine/RepairEngine.php';
require_once __DIR__ . '/engine/Fixer.php';

echo PHP_EOL;
echo "==============================================" . PHP_EOL;
echo "        NexusAI Developer Engine v2.0" . PHP_EOL;
echo "==============================================" . PHP_EOL;
echo PHP_EOL;

$project = "/var/www/html/public";

$scanner = new Scanner();
$analyzer = new Analyzer($scanner);

echo "[1/5] Scanning project..." . PHP_EOL;

$analyzer->analyze($project);

echo "Done." . PHP_EOL;
echo PHP_EOL;

echo "[2/5] Building repair tasks..." . PHP_EOL;

$decision = new DecisionEngine();
$approval = new ApprovalManager();

foreach ($scanner->all() as $issue) {

    $task = $decision->decide($issue);

    if ($task !== null) {
        $approval->add($task);
    }

}

echo "Done." . PHP_EOL;
echo PHP_EOL;

echo "[3/5] Summary" . PHP_EOL;
echo "----------------------------------------" . PHP_EOL;

echo "Issues Found : " . $scanner->count() . PHP_EOL;
echo "Pending Tasks: " . count($approval->all()) . PHP_EOL;

echo PHP_EOL;

foreach ($scanner->all() as $issue) {

    echo "[" . strtoupper($issue->severity) . "] ";
    echo $issue->type . PHP_EOL;
    echo $issue->file . PHP_EOL;
    echo $issue->message . PHP_EOL;
    echo PHP_EOL;

}

echo "[4/5] Waiting for approval..." . PHP_EOL;
echo PHP_EOL;

echo "Use NexusAI Chat to approve repairs." . PHP_EOL;

echo PHP_EOL;
echo "[5/5] Finished." . PHP_EOL;

echo PHP_EOL;
echo "==============================================" . PHP_EOL;
echo " NexusAI Ready" . PHP_EOL;
echo "==============================================" . PHP_EOL;
#!/bin/bash

ROOT="/var/www/html/nexusai"

clear

echo "======================================="
echo "         NexusAI 2.0"
echo "======================================="
echo

read -p "أدخل الأمر: " REQUEST

REQUEST=$(echo "$REQUEST" | tr '[:upper:]' '[:lower:]')

########################################################

if [[ "$REQUEST" == *"افحص"* ]] && [[ "$REQUEST" == *"النظام"* ]]; then
    bash "$ROOT/modules/report.sh"
    exit
fi

########################################################

if [[ "$REQUEST" == *"apache"* ]]; then
    bash "$ROOT/modules/apache.sh"
    exit
fi

########################################################

if [[ "$REQUEST" == *"php"* ]]; then
    bash "$ROOT/modules/php.sh"
    exit
fi

########################################################

if [[ "$REQUEST" == *"قاعدة"* ]]; then
    bash "$ROOT/modules/database.sh"
    exit
fi

########################################################

if [[ "$REQUEST" == *"api"* ]]; then
    bash "$ROOT/modules/api.sh"
    exit
fi

########################################################

if [[ "$REQUEST" == *"صفحة"* ]]; then
    bash "$ROOT/modules/pages.sh"
    exit
fi

########################################################

if [[ "$REQUEST" == *"ادمن"* ]] || [[ "$REQUEST" == *"لوحة"* ]]; then
    bash "$ROOT/modules/admin.sh"
    exit
fi

########################################################

if [[ "$REQUEST" == *"نشر"* ]]; then
    bash "$ROOT/modules/deploy.sh"
    exit
fi

########################################################

if [[ "$REQUEST" == *"نسخة"* ]]; then
    bash "$ROOT/modules/backup.sh"
    exit
fi

########################################################

echo
echo "لم أفهم الأمر."
echo
echo "مثال:"
echo "افحص النظام"
echo "افحص قاعدة البيانات"
echo "افحص صفحات الموقع"
echo "افحص api"
echo "جهز النظام للنشر"
echo
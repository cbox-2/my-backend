#!/bin/bash

echo
echo "============== NexusAI =============="
echo

echo "check system"
echo "check apache"
echo "check php"
echo "check database"
echo "check pages"
echo "check api"

echo

echo "repair page"
echo "repair admin"

echo

echo "create page"

echo

echo "deploy"

echo
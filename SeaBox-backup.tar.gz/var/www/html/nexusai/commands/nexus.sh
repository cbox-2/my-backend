#!/bin/bash

source /var/www/html/nexusai/config.conf

clear

echo "======================================="
echo "          NexusAI Console"
echo "======================================="
echo

read -p "NexusAI> " CMD

case "$CMD" in

"check system")
bash /var/www/html/nexusai/commands/production-check.sh
;;

"check apache")
bash /var/www/html/nexusai/commands/apache-check.sh
;;

"check php")
bash /var/www/html/nexusai/commands/php-check.sh
;;

"check database")
bash /var/www/html/nexusai/commands/database-check.sh
;;

"check pages")
bash /var/www/html/nexusai/commands/pages-check.sh
;;

"check api")
bash /var/www/html/nexusai/commands/api-check.sh
;;

"repair admin")
bash /var/www/html/nexusai/commands/repair-admin.sh
;;

"repair page")
bash /var/www/html/nexusai/commands/repair-page.sh
;;

"create page")
bash /var/www/html/nexusai/commands/create-page.sh
;;

"deploy")
bash /var/www/html/nexusai/commands/deploy.sh
;;

*)
echo
echo "الأمر غير معروف."
;;

esac
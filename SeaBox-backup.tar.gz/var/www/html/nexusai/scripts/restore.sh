#!/bin/bash

BACKUP_DIR="/var/www/html/nexusai/backups"

echo "===================================="
echo "      NexusAI Restore"
echo "===================================="

echo ""
echo "النسخ الاحتياطية الموجودة:"
ls -lh "$BACKUP_DIR"

echo ""
echo "هذه النسخة لا تسترجع الملفات تلقائياً حالياً."
echo "سيتم إضافة الاسترجاع الآمن في المرحلة القادمة."
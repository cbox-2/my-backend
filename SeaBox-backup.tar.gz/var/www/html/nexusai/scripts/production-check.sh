#!/bin/bash

PROJECT="/var/www/html"
REPORT="/var/www/html/nexusai/reports/report-$(date +%F-%H-%M-%S).txt"

echo "=========================================" > "$REPORT"
echo "       NexusAI Production Report" >> "$REPORT"
echo "=========================================" >> "$REPORT"

echo "" >> "$REPORT"
echo "Date: $(date)" >> "$REPORT"

echo "" >> "$REPORT"
echo "========== SYSTEM ==========" >> "$REPORT"
hostname >> "$REPORT"
whoami >> "$REPORT"
pwd >> "$REPORT"

echo "" >> "$REPORT"
echo "========== PHP ==========" >> "$REPORT"
php -v | head -1 >> "$REPORT"

echo "" >> "$REPORT"
echo "========== APACHE ==========" >> "$REPORT"
apache2 -v | head -1 >> "$REPORT" 2>/dev/null

echo "" >> "$REPORT"
echo "========== PHP SYNTAX ==========" >> "$REPORT"

ERRORS=$(find "$PROJECT" -name "*.php" -exec php -l {} \; | grep -v "No syntax errors")

if [ -z "$ERRORS" ]; then
    echo "No PHP syntax errors." >> "$REPORT"
else
    echo "$ERRORS" >> "$REPORT"
fi

echo "" >> "$REPORT"
echo "========== CBOX LINKS ==========" >> "$REPORT"

LINKS=$(grep -Rni "cbox\.ws" "$PROJECT" --include="*.php" --include="*.html")

if [ -z "$LINKS" ]; then
    echo "No old Cbox links found." >> "$REPORT"
else
    echo "$LINKS" >> "$REPORT"
fi

echo "" >> "$REPORT"
echo "========== DATABASE ==========" >> "$REPORT"

mysql -u nexusbox -p'NexusBox2026' \
-e "USE nexusbox_db; SHOW TABLES;" >> "$REPORT" 2>&1

echo "" >> "$REPORT"
echo "========== APACHE ERRORS ==========" >> "$REPORT"

tail -20 /var/log/apache2/error.log >> "$REPORT" 2>/dev/null

echo "" >> "$REPORT"
echo "========== HTTP ==========" >> "$REPORT"

curl -I http://localhost/ >> "$REPORT" 2>&1

echo "" >> "$REPORT"
echo "========== FINISHED ==========" >> "$REPORT"

echo "Report saved:"
echo "$REPORT"
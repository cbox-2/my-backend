#!/bin/bash

PROJECT="/var/www/html"
BACKUP_DIR="/var/www/html/nexusai/backups"
DATE=$(date +%Y-%m-%d_%H-%M-%S)

mkdir -p "$BACKUP_DIR"

echo "===================================="
echo "      NexusAI Backup System"
echo "===================================="

echo ""
echo "إنشاء نسخة احتياطية..."

tar -czf "$BACKUP_DIR/nexusbox_$DATE.tar.gz" "$PROJECT"

echo ""
echo "تم إنشاء النسخة الاحتياطية:"
echo "$BACKUP_DIR/nexusbox_$DATE.tar.gz"

echo ""
echo "النسخ الموجودة:"
ls -lh "$BACKUP_DIR"
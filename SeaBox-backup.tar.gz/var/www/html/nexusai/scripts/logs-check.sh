#!/bin/bash

echo "=================================="
echo " LOGS CHECK"
echo "=================================="

echo
echo "Apache Errors"

tail -50 /var/log/apache2/error.log

echo
echo "Finished."
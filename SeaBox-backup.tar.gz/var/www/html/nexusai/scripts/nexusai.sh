#!/bin/bash

clear

while true
do
echo "========================================="
echo "        NexusAI Management System"
echo "========================================="
echo
echo "1) فحص النظام"
echo "2) إصلاح النظام"
echo "3) إنشاء نسخة احتياطية"
echo "4) استعراض النسخ الاحتياطية"
echo "5) خروج"
echo
read -p "اختر رقم: " CHOICE

case $CHOICE in

1)
echo
bash /var/www/html/nexusai/scripts/production-check.sh
;;

2)
echo
bash /var/www/html/nexusai/scripts/fix-system.sh
;;

3)
echo
bash /var/www/html/nexusai/scripts/backup.sh
;;

4)
echo
ls -lh /var/www/html/nexusai/backups
;;

5)
exit
;;

*)
echo "خيار غير صحيح"
;;

esac

echo
read -p "اضغط Enter للعودة..."
clear

done
#!/bin/bash

PROJECT="/var/www/html"

echo "======================================="
echo " NexusAI Fix System"
echo "======================================="
echo

echo "[1] البحث عن روابط Cbox القديمة..."
grep -Rni "cbox\.ws" "$PROJECT" --include="*.php" --include="*.html"

echo
echo "[2] البحث عن localhost..."
grep -RniE "localhost|127\.0\.0\.1" "$PROJECT"

echo
echo "[3] البحث عن ملفات PHP التي تحتوي أخطاء..."
find "$PROJECT" -name "*.php" -exec php -l {} \; | grep -v "No syntax errors"

echo
echo "[4] فحص الملفات المفقودة..."
for file in \
"$PROJECT/api/login.php" \
"$PROJECT/api/register.php" \
"$PROJECT/api/logout.php" \
"$PROJECT/api/db.php"
do
    if [ -f "$file" ]; then
        echo "✔ موجود: $file"
    else
        echo "✘ مفقود: $file"
    fi
done

echo
echo "[5] انتهى الفحص."
echo
echo "في الإصدار القادم سيتم تنفيذ الإصلاحات تلقائياً بعد موافقتك."
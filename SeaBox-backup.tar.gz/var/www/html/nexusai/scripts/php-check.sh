#!/bin/bash

source /var/www/html/nexusai/config.conf

echo "=================================="
echo " PHP Check"
echo "=================================="

php -v

echo
echo "Checking PHP syntax..."

find $PROJECT_ROOT -name "*.php" -exec php -l {} \; | grep -v "No syntax errors"

echo

echo "Finished."
#!/bin/bash

source /var/www/html/nexusai/config.conf

echo "=================================="
echo " Database Check"
echo "=================================="

mysql -u $MYSQL_USER -p$MYSQL_PASS <<EOF

USE $MYSQL_DB;

SHOW TABLES;

SELECT COUNT(*) AS Users FROM users;

EOF

echo

echo "Finished."
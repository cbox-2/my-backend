#!/bin/bash

source /var/www/html/nexusai/config.conf

echo "======================================="
echo " NexusAI Create Page"
echo "======================================="

echo

read -p "اسم الصفحة الجديدة: " PAGE

mkdir -p "$PUBLIC_DIR/$PAGE"

cp "$PUBLIC_DIR/index/index.html" "$PUBLIC_DIR/$PAGE/index.html"

cp "$PUBLIC_DIR/index/style.css" "$PUBLIC_DIR/$PAGE/style.css"

cp "$PUBLIC_DIR/index/code.js" "$PUBLIC_DIR/$PAGE/code.js"

echo

echo "تم إنشاء الصفحة."

echo "$PUBLIC_DIR/$PAGE"
#!/bin/bash

source /var/www/html/nexusai/config.conf

echo "======================================="
echo " NexusAI Admin Repair"
echo "======================================="

echo

find $ADMIN_DIR -type f

echo

grep -Rni "cbox.ws" $ADMIN_DIR

echo

find $ADMIN_DIR -name "*.php" -exec php -l {} \;

echo

echo "انتهى."
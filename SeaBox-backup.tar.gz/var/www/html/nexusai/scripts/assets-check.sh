#!/bin/bash

source /var/www/html/nexusai/config.conf

echo "=================================="
echo " ASSETS CHECK"
echo "=================================="

echo
echo "Images"

find $PROJECT_ROOT -iname "*.png"
find $PROJECT_ROOT -iname "*.jpg"
find $PROJECT_ROOT -iname "*.gif"

echo
echo "Fonts"

find $PROJECT_ROOT -iname "*.woff"
find $PROJECT_ROOT -iname "*.woff2"

echo
echo "CSS"

find $PROJECT_ROOT -iname "*.css"

echo
echo "JavaScript"

find $PROJECT_ROOT -iname "*.js"

echo
echo "Finished."
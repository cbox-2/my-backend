#!/bin/bash

source /var/www/html/nexusai/config.conf

echo "=================================="
echo " Apache Check"
echo "=================================="

systemctl status $WEB_SERVER --no-pager

echo
echo "Testing Web Server..."

$CURL_BIN -I $HOST/

echo
echo "Apache Version"

apache2 -v

echo
echo "Done."
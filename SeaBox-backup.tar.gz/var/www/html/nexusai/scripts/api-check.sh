#!/bin/bash

source /var/www/html/nexusai/config.conf

echo "=================================="
echo " API CHECK"
echo "=================================="

find $API_DIR -type f

echo
echo "Testing APIs..."

for api in $(find $API_DIR -name "*.php")
do
    echo "----------------------------------"
    echo "$api"
    php -l "$api"
done

echo
echo "Finished."
#!/bin/bash

source /var/www/html/nexusai/config.conf

echo "=================================="
echo " SECURITY CHECK"
echo "=================================="

echo
echo "Searching for localhost..."

grep -RniE "localhost|127\.0\.0\.1" $PROJECT_ROOT

echo
echo "Searching old links..."

grep -Rni "cbox\.ws" $PROJECT_ROOT

echo
echo "Searching debug functions..."

grep -RniE "phpinfo|var_dump|print_r|die\(|exit\(" $PROJECT_ROOT --include="*.php"

echo
echo "Finished."
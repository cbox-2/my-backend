#!/bin/bash

source /var/www/html/nexusai/config.conf

echo "======================================="
echo " NexusAI API Repair"
echo "======================================="

echo

find $API_DIR -name "*.php" | while read FILE
do

echo
echo "$FILE"

php -l "$FILE"

done

echo

echo "انتهى."
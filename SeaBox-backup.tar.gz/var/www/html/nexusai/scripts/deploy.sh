#!/bin/bash

source /var/www/html/nexusai/config.conf

echo "======================================="
echo " NexusAI Deploy"
echo "======================================="

echo

bash /var/www/html/nexusai/scripts/backup.sh

echo

bash /var/www/html/nexusai/scripts/production-check.sh

echo

bash /var/www/html/nexusai/scripts/apache-check.sh

echo

bash /var/www/html/nexusai/scripts/php-check.sh

echo

bash /var/www/html/nexusai/scripts/database-check.sh

echo

echo "النظام جاهز للفحص النهائي."
#!/bin/bash

source /var/www/html/nexusai/config.conf

echo "=================================="
echo " PERMISSIONS CHECK"
echo "=================================="

find $PROJECT_ROOT -type f | head -100 | while read FILE
do
    stat -c "%a %U:%G %n" "$FILE"
done

echo
echo "Finished."
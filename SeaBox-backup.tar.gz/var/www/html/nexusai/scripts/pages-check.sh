#!/bin/bash

source /var/www/html/nexusai/config.conf

echo "=================================="
echo " Pages Check"
echo "=================================="

find $PUBLIC_DIR -name "index.*"

echo

echo "Broken links"

grep -Rni "cbox\.ws" $PUBLIC_DIR

echo

echo "Finished."
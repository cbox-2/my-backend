#!/bin/bash

source /var/www/html/nexusai/config.conf

echo "======================================="
echo " NexusAI Page Repair"
echo "======================================="

echo

read -p "أدخل مسار الصفحة: " PAGE

if [ ! -f "$PAGE" ]; then
    echo
    echo "الملف غير موجود."
    exit
fi

echo
echo "فحص الصفحة..."

grep -n "cbox.ws" "$PAGE"

grep -n "localhost" "$PAGE"

grep -n "127.0.0.1" "$PAGE"

echo
echo "انتهى الفحص."
echo
echo "الإصلاح التلقائي سيضاف في المرحلة القادمة."
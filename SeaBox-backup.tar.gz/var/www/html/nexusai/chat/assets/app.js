const send = document.getElementById("send");
const message = document.getElementById("message");
const chat = document.getElementById("chat");

function addMessage(text, type) {

    const div = document.createElement("div");

    div.className = type === "user" ? "user" : "ai";

    div.innerHTML = text;

    chat.appendChild(div);

    chat.scrollTop = chat.scrollHeight;
}

function sendMessage() {

    const text = message.value.trim();

    if (text === "") {
        return;
    }

    addMessage(text, "user");

    message.value = "";

    fetch("api/chat.php", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({
            message: text
        })
    })
    .then(response => response.json())
    .then(data => {

        if (data.success) {
            addMessage(data.message, "ai");
        } else {
            addMessage("❌ " + data.message, "ai");
        }

    })
    .catch(error => {

        console.error(error);

        addMessage("تعذر الاتصال بمحرك NexusAI", "ai");

    });

}

send.onclick = sendMessage;

message.addEventListener("keydown", function (e) {

    if (e.key === "Enter") {
        sendMessage();
    }

});
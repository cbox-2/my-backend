<?php

declare(strict_types=1);

header("Content-Type: application/json; charset=utf-8");

require_once __DIR__ . "/../../engine/ApprovalManager.php";
require_once __DIR__ . "/../../engine/Fixer.php";

$approval = new ApprovalManager();
$fixer = new Fixer();

$results = $fixer->executeApproved($approval);

echo json_encode([
    "success" => true,
    "executed" => count($results),
    "results" => $results
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
<?php

header("Content-Type: application/json; charset=UTF-8");

require_once "/var/www/html/nexusai/engine/CommandProcessor.php";

try {

    $input = file_get_contents("php://input");

    if (!$input) {
        throw new Exception("لم يتم إرسال طلب");
    }

    $data = json_decode($input, true);

    if (!isset($data["message"])) {
        throw new Exception("الأمر غير موجود");
    }

    $message = trim($data["message"]);

    if ($message === "") {
        throw new Exception("الأمر فارغ");
    }


    // مسار مشروع Cbox
    $projectPath = "/var/www/html";


    $processor = new CommandProcessor($projectPath);


    $response = $processor->process($message);


    echo json_encode([
        "success" => true,
        "message" => $response
    ], JSON_UNESCAPED_UNICODE);


} catch (Throwable $e) {

    echo json_encode([
        "success" => false,
        "message" => $e->getMessage()
    ], JSON_UNESCAPED_UNICODE);

}

?>
<?php

declare(strict_types=1);

header("Content-Type: application/json; charset=utf-8");

$tasksFile = __DIR__ . "/../../reports/tasks.json";


if (!file_exists($tasksFile)) {

    echo json_encode([
        "success" => false,
        "message" => "No tasks found",
        "tasks" => []
    ], JSON_UNESCAPED_UNICODE);

    exit;
}


$data = json_decode(
    file_get_contents($tasksFile),
    true
);


if (!is_array($data)) {

    echo json_encode([
        "success" => false,
        "message" => "Invalid tasks file",
        "tasks" => []
    ], JSON_UNESCAPED_UNICODE);

    exit;
}


echo json_encode([
    "success" => true,
    "count" => count($data),
    "tasks" => $data
], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
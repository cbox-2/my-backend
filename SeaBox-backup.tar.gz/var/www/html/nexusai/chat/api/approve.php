<?php

declare(strict_types=1);

header("Content-Type: application/json; charset=utf-8");

require_once __DIR__ . "/../../engine/ApprovalManager.php";


$id = $_GET["id"] ?? null;


if (!$id) {

    echo json_encode([
        "success" => false,
        "message" => "Task ID missing"
    ]);

    exit;
}


$approval = new ApprovalManager();


$result = $approval->approve($id);


echo json_encode([

    "success" => $result,

    "message" => $result
        ? "Task approved"
        : "Task not found"

], JSON_PRETTY_PRINT);
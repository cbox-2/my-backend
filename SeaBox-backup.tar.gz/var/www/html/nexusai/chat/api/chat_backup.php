<?php

header("Content-Type: application/json; charset=UTF-8");

$message = trim($_POST['message'] ?? '');

$project = "/var/www/html";


if(strpos($message,"اعرض الملفات") !== false){

    $items = scandir($project);

    $list = "";

    foreach($items as $item){

        if($item != "." && $item != ".."){

            $list .= "📁 ".$item."<br>";

        }

    }

    $reply = "ملفات مشروع Cbox:<br><br>".$list;


}

else if(strpos($message,"فحص المشروع") !== false){

    $check = [
        "admin",
        "api",
        "public",
        "index.html",
        "code.js"
    ];

    $missing = [];

    foreach($check as $file){

        if(!file_exists($project."/".$file)){

            $missing[] = $file;

        }

    }


    if(empty($missing)){

        $reply = "✅ تم فحص المشروع. الملفات الأساسية موجودة.";

    }
    else{

        $reply = "⚠️ ملفات مفقودة:<br>".implode("<br>",$missing);

    }


}


else if(strpos($message,"ابحث عن خطأ") !== false){

    $reply = "🔍 بدأ البحث عن الأخطاء داخل ملفات المشروع...";

}


else if($message == "هلو" || $message == "مرحبا"){

    $reply = "هلو 👋 أنا NexusAI. جاهز لمساعدتك في مشروع Cbox.";

}


else{

    $reply = "استلمت طلبك: ".$message;

}



echo json_encode(
    [
        "reply"=>$reply
    ],
    JSON_UNESCAPED_UNICODE
);

?>
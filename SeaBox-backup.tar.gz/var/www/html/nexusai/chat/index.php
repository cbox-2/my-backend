<!DOCTYPE html>
<html lang="ar" dir="rtl">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>NexusAI Developer Console</title>

<link rel="stylesheet" href="assets/style.css">

</head>

<body>

<div class="container">

    <div class="header">
        <h1>NexusAI</h1>
        <span>Developer Console</span>
    </div>

    <div id="chat" class="chat">

        <div class="ai">

            <strong>مرحباً 👋</strong>

            <br><br>

            أنا <b>NexusAI</b>.

            <br>

            اكتب أي أمر لإدارة مشروع Cbox.

            <br><br>

            <b>الأوامر المتاحة:</b>

            <br><br>

            ✅ فحص المشروع

            <br>

            ✅ اعرض المشاكل

            <br>

            ✅ اعرض المهام

            <br>

            ✅ نفذ الإصلاح

            <br>

            ✅ الإحصائيات

        </div>

    </div>

    <div class="input">

        <input
            id="message"
            type="text"
            autocomplete="off"
            placeholder="اكتب طلبك هنا..."
        >

        <button id="send">
            إرسال
        </button>

    </div>

</div>

<script src="assets/app.js?v=2"></script>

</body>

</html>